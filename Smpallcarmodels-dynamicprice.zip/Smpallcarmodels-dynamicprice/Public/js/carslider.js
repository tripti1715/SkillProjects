
      $(" .cardss .priceingTag").each(function () {
        var itemPriceRange = $(this).text();
        var str = itemPriceRange.toString().split("-");
        if (str == "") {
          str[0] = "NA";
          str[1] = "NA";
        } else if (str.length == 1) {
          str[0] = str[0].replace(/\B(?=(?:(\d\d)+(\d)(?!\d))+(?!\d))/g, " ");
        } else if (str[0] == "" && str[1] > 0) {
          str[1] = str[1].replace(/\B(?=(?:(\d\d)+(\d)(?!\d))+(?!\d))/g, " ");
          str[0] = "NA";
        } else if (str[0] > 0 && str[1] > 0) {
          str[0] = str[0].replace(/\B(?=(?:(\d\d)+(\d)(?!\d))+(?!\d))/g, " ");
          str[1] = str[1].replace(/\B(?=(?:(\d\d)+(\d)(?!\d))+(?!\d))/g, " ");
        }

        if (str.length == 1) {
          var newdata = str[0].split(".");
          var num1 = newdata[0] == "NA" ? "NA" : newdata[0];

          console.log(num1);
        //   $(".cardss").append("<p>" + num1 + " </p>");
        //   $(".priceingTag").remove();
        } else {
          var newdata = str[0].split(".");
          var newdata2 = str[1].split(".");
          var num1 = newdata[0] == "NA" ? "NA" : newdata[0];
          var num2 = newdata2[0] == "NA" ? "NA" : newdata2[0];
          var concat = num1 + " - " + num2;

          console.log(concat);
        //   $(".cardss").append("<p>" + concat + " </p>");
        //   $(".priceingTag").remove();
        }
      });
    