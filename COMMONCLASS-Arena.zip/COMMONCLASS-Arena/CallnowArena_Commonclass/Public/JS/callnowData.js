// Disclaimer Toggle
$(document).ready(function () {
  $("#disclaimersText").hide();
  $("#SubmitData").hide();
  $("#disclaimerbtn-id").click(function () {
    $("#disclaimersText").toggle();
  });
});

var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 3000);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}

// Valid Bollean
valid = false;
validName = false;
validEmail = false;
validContact = false;
validModel = false;
validAgree = false;
var row = 1;
function validate() {
  //   Get Form Values
  debugger;
  var names = document.getElementById("usrs").value;
  var emails = document.getElementById("txtemail").value;
  var phoneNo = document.getElementById("txtphonene").value;
  var Selctmodel = document.getElementById("drpModel").value + "hello";
  var box = document.getElementById("disclaimer").checked;
  // Regexp
  var validMobileRegex = /^[789]\d{9}$/;
  var ValidUserCheck = /^[A-Z a-z]+$/;
  // Condition if Form Submitted Blank
  if (names == "" && emails == "" && phoneNo == "" && Selctmodel == "0") {
    document.getElementById("nameerror").innerHTML =
      "*Please fill the username";
    document.getElementById("emailerror").innerHTML = "*Please fill the email";
    document.getElementById("contacterror").innerHTML =
      "*Please fill the Phone No";
    document.getElementById("modelerror").innerHTML = "*Please select a model";
  } else {
    // --------------------------------------------
    if (names == "") {
      document.getElementById("nameerror").innerHTML = "Name can not be empty";
    } else if (!ValidUserCheck.test(names)) {
      document.getElementById("nameerror").innerHTML =
        "*Only characters are allowed";
    } else if (names.length < 3) {
      document.getElementById("nameerror").innerHTML =
        "Username must be at least 3 characters";
    } else if (names.length > 15) {
      document.getElementById("nameerror").innerHTML =
        "Username must be at less than 20 characters";
    } else {
      document.getElementById("nameerror").innerHTML = "";
      this.validName = true;
    }
    // ----------------Emails----------------------------
    if (emails == "") {
      document.getElementById("emailerror").innerHTML =
        "Email can not be empty";
    } else if (emails.indexOf("@") <= 0) {
      document.getElementById("emailerror").innerHTML =
        "*Email (abc@gmail.com) must contain '@' ";
    } else if (
      emails.charAt(emails.length - 4) != "." &&
      emails.charAt(emails.length - 3) != "."
    ) {
      document.getElementById("emailerror").innerHTML =
        "*Email (abc@gmail.com) must contain '.'";
    } else {
      document.getElementById("emailerror").innerHTML = "";
      this.validEmail = true;
    }

    // --------------Contact Number------------------
    if (phoneNo == "") {
      document.getElementById("contacterror").innerHTML =
        "*Phone No. can not be empty";
    } else if (isNaN(phoneNo)) {
      document.getElementById("contacterror").innerHTML =
        "*Must be digits only";
    } else if (phoneNo.length != 10) {
      document.getElementById("contacterror").innerHTML =
        "*Mobile no must be 10 digits only";
    } else if (!validMobileRegex.test(phoneNo)) {
      document.getElementById("contacterror").innerHTML =
        "*Number is not valid";
    } else {
      document.getElementById("contacterror").innerHTML = "";
      this.validContact = true;
    }

    // --------------Select Box---------------------
    if (Selctmodel == "0") {
      document.getElementById("modelerror").innerHTML =
        "*Please select a model";
    } else {
      document.getElementById("modelerror").innerHTML = "";
      this.validModel = true;
    }
    //------------checkbox-----------------------
    if (!box) {
      debugger;
      document.getElementById("checkboxerror").innerHTML =
        "Please agree Disclaimers";
    } else {
      document.getElementById("checkboxerror").innerHTML = "";
      this.validAgree = true;
      this.isValid();
    }
  }
}
function isValid() {
  //var display = document.getElementById("modelss");

  if (validName && validEmail && validContact && validModel && validAgree) {
    // var newRow = display.insertRow(row);
    // var cell1 = newRow.insertCell(0);
    // var cell2 = newRow.insertCell(1);
    // var cell3 = newRow.insertCell(2);
    // var cell4 = newRow.insertCell(3);

    // // cell1 = innerHTML.names;
    // // cell2 = innerHTML.emails;
    // // cell3 = innerHTML.phoneNo;
    // // cell4 = innerHTML.Selctmodel;
    //row++;
    var name = $("#usrs").val();
    var email = $("#txtemail").val();
    var phoneN = $("#txtphonene").val();
    var Selctmodel = $("#drpModel").val();

    var str =
      "" +
      "NAME-" +
      name +
      "<br>" +
      " EMAIL-" +
      email +
      "<br>" +
      "PHONE-NO-" +
      phoneN +
      "<br>" +
      "MODEL-" +
      Selctmodel +
      "hello";
    $("#modelss").html(str);
    $("#SubmitData").modal("show");
    $("#registrationForm")[0].reset();
  } else {
    alert("Fill the form");
  }
}
