function myFunction() {
  var x = document.getElementById("myDIV");
  var y = document.getElementById("marutiNav");
  var z = document.getElementById("marutiNavbar");
  var b = document.getElementById("imagechange");

  // var elem = document.getElementById("myAnimation");
  var pos = 0;
  clearInterval();
  id = setInterval(frame, 10);
  function frame() {
    if (pos == 350) {
      clearInterval(id);
    } else {
      pos++;
      x.style.top = pos + "px";
      x.style.left = pos + "px";
    }
  }
  if (x.style.display === "none") {
    x.style.display = "block";
    x.style.transform.tran;
    b.src = "./PUBLIC/ASSETS/close.png";
    y.style.display = "none";
    z.style.display = "none";
  } else {
    x.style.display = "none";
    y.style.display = "block";
    z.style.display = "";
    b.src = "./PUBLIC/ASSETS/menuicon.png";
  }
}
//}

$(document).ready(function () {
  $("#myDIV").hide();
});

// function abc()
// {
//   alert("heloo");
// }
